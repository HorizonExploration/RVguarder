"""PMKB relation resources."""
