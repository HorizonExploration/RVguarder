"""PMKB rule resources."""
