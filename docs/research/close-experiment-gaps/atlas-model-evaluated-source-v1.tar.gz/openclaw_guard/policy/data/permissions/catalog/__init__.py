"""PMKB operation catalog resources."""
