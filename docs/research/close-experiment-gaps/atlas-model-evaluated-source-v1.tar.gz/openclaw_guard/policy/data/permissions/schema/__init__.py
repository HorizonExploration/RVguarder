"""PMKB schema resource package."""
