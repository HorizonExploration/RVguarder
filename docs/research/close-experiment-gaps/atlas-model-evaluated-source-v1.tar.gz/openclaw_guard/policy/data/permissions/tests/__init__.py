"""PMKB vector resources."""
